## 1.0.3, 2018-5-5

* Add lightweight Objective-C generics annotations [capnslipp]

## 1.0.2

* Remove prefix header to appease CocoaPods

## 1.0.1

* Fix compilation error in Xcode 9

## 1.0.0

* First CocoaPods release.
